"""SUMO/TraCI integration utilities."""
